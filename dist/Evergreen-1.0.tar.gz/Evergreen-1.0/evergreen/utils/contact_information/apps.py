from __future__ import unicode_literals

from django.apps import AppConfig


class ContactInformationConfig(AppConfig):
    name = 'contact_information'
